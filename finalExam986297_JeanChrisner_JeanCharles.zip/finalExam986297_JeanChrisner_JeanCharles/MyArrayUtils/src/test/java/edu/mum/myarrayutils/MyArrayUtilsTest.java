package edu.mum.myarrayutils;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class MyArrayUtilsTest {

    MyArrayUtils myArrayUtils=null;

    @Before
    public void setUp() throws Exception {
        myArrayUtils=new MyArrayUtils();
    }

    @After
    public void tearDown() throws Exception {
        myArrayUtils=null;
    }

    @Test
    public void hasMultipleMaximum1() {

        int[] input={-6, 2, 5, 6, -6, 5, 6};
        assertTrue(myArrayUtils.hasMultipleMaximum(input));
    }

    @Test
    public void nullInput() {
        int[] input=null;
        assertFalse(myArrayUtils.hasMultipleMaximum(input));
    }
    @Test
    public void emptyInput() {
        int[] input={};
        assertFalse(myArrayUtils.hasMultipleMaximum(input));
    }



}