package edu.mum.myarrayutils;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyarrayutilsApplication implements CommandLineRunner {

    public static void main(String[] args) {
        SpringApplication.run(MyarrayutilsApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {

    }
}
