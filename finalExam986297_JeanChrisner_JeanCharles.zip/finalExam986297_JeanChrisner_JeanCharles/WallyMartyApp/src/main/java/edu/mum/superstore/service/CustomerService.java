package edu.mum.superstore.service;

import edu.mum.superstore.model.Customer;

import java.util.List;

public interface CustomerService {

    public Customer addCustomer(Customer customer);
    public List<Customer> getCustomers();

    public List<Customer> getPrimeCustomers();
}
