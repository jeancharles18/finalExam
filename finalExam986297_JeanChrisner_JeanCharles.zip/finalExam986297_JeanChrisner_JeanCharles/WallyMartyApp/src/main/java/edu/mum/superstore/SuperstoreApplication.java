package edu.mum.superstore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SuperstoreApplication {

    public static void main(String[] args) {
        SpringApplication.run(SuperstoreApplication.class, args);
    }
}
