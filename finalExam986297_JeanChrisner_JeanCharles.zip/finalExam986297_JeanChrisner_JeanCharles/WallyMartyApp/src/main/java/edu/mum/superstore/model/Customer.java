package edu.mum.superstore.model;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import java.util.Date;

@Entity
public class Customer {
    @Id
    @GeneratedValue
    private long id;
    private String customerNumer;
    private  String name;
    private String phoneNumber;
    private Date dateOfBirth;

    public Customer() {

    }

    public Customer(String customerNumer, String name, String phoneNumber, Date dateOfBirth) {
        this.customerNumer = customerNumer;
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.dateOfBirth = dateOfBirth;
    }


    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getCustomerNumer() {
        return customerNumer;
    }

    public void setCustomerNumer(String customerNumer) {
        this.customerNumer = customerNumer;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }
}
