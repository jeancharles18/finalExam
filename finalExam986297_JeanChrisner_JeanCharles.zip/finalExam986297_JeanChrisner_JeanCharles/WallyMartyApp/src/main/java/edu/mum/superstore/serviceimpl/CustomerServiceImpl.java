package edu.mum.superstore.serviceimpl;

import edu.mum.superstore.model.Customer;
import edu.mum.superstore.repository.CustomerRepository;
import edu.mum.superstore.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustomerServiceImpl implements CustomerService {

    @Autowired
    CustomerRepository customerRepository;
    @Override
    public Customer addCustomer(Customer customer) {
        return customerRepository.save(customer);
    }

    @Override
    public List<Customer> getCustomers() {
        return (List<Customer> ) customerRepository.findAll();
    }

    @Override
    public List<Customer> getPrimeCustomers() {
        return null;
    }
}
