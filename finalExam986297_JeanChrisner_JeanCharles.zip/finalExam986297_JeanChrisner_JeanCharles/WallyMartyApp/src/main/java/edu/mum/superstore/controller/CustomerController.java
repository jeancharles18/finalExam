package edu.mum.superstore.controller;


import edu.mum.superstore.model.Customer;
import edu.mum.superstore.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class CustomerController {

    @Autowired
    CustomerService customerService;

    @GetMapping("/customers")
    public String getCustomers(Model model){

        model.addAttribute("customers",customerService.getCustomers());
        return "customer/pagecustomer";
    }


    @GetMapping("/customer/new")
    public String formProduct(@ModelAttribute("customer")Customer customer, Model model){



        return "customer/newcustomer";
    }

    @PostMapping("/customer/new")
    public String save(@ModelAttribute("customer") Customer customer, BindingResult bindingResult, Model model){

        if (bindingResult.hasErrors()){

            model.addAttribute("errors",bindingResult.getAllErrors());

            return "customer/newCustomer";
        }
        model.addAttribute("customer",customerService.addCustomer(customer));

        return   "redirect:/customers";
    }










}
